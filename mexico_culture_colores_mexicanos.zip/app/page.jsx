
'use client'
import Header from '../components/Header'

export default function HomePage() {
  return (
    <main className="min-h-screen bg-[#fffaf0] text-gray-900">
      <Header />
      <div className="p-8 text-center">
        <h2 className="text-3xl font-bold mb-4">Explora el sabor de México</h2>
        <p className="mb-8">Descubre platillos tradicionales, bebidas refrescantes y postres deliciosos</p>
        <button
          onClick={() => window.location.href='/categorias'}
          className="bg-[#c1272d] text-white px-6 py-3 rounded-full hover:bg-[#a31e24]"
        >
          Ver categorías
        </button>
      </div>
    </main>
  )
}
