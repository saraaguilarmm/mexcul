
'use client'
import { useState } from 'react'
import { useRouter } from 'next/navigation'

export default function Header() {
  const [menuOpen, setMenuOpen] = useState(false)
  const router = useRouter()

  return (
    <header className="bg-[#006847] text-white px-4 py-3 flex items-center justify-between">
      <div className="flex items-center gap-4">
        <button
          onClick={() => setMenuOpen(!menuOpen)}
          className="text-white text-2xl font-bold"
        >
          ☰
        </button>
        <h1 className="text-xl font-bold">MÉXICO CULTURE</h1>
      </div>

      <div className="flex-1 mx-4">
        <input
          type="text"
          placeholder="Busca una receta, ingrediente..."
          className="w-full px-4 py-2 rounded text-black"
        />
      </div>

      <div className="flex gap-2 text-sm font-semibold">
        <button onClick={() => router.push('/resena')} className="bg-white text-[#006847] px-2 py-1 rounded hover:bg-[#cce6d4]">AÑADIR RESEÑA / CALIFICAR</button>
        <button className="bg-[#004c36] px-2 py-1 rounded hover:bg-[#003f2e]">REGÍSTRATE</button>
        <button className="bg-[#004c36] px-2 py-1 rounded hover:bg-[#003f2e]">INICIA SESIÓN</button>
      </div>

      {menuOpen && (
        <div className="absolute top-16 left-0 w-full bg-[#004c36] text-white p-4 shadow-md z-50">
          <ul className="space-y-2">
            <li><button onClick={() => router.push('/cambiar-idioma')}>🌐 Cambiar idioma</button></li>
            <li><button onClick={() => router.push('/mis-recetas')}>🧾 Mis Recetas</button></li>
            <li><button onClick={() => router.push('/favoritos')}>⭐ Favoritos</button></li>
            <li><button onClick={() => router.push('/colecciones')}>📚 Colecciones</button></li>
            <li><button onClick={() => router.push('/subir-receta')}>⬆️ Subir receta</button></li>
            <li><button onClick={() => router.push('/planear-menu')}>📅 Planear menú</button></li>
          </ul>
        </div>
      )}
    </header>
  )
}
