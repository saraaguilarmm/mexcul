
'use client'
import { useRouter } from 'next/navigation'

export default function HomePage() {
  const router = useRouter()

  return (
    <main className="min-h-screen bg-[#fef9f4] text-gray-900">
      <header className="bg-[#c1272d] text-white p-4 flex justify-between items-center">
        <h1 className="text-xl font-extrabold">🇲🇽 MÉXICO CULTURE</h1>
        <div className="relative group">
          <button className="bg-[#006847] px-4 py-2 rounded hover:bg-[#004c36]">☰ Menú</button>
          <ul className="absolute right-0 mt-2 bg-white text-black rounded shadow-md w-56 hidden group-hover:block z-50">
            <li><button onClick={() => router.push('/cambiar-idioma')} className="block w-full text-left px-4 py-2 hover:bg-gray-100">🌐 Cambiar idioma</button></li>
            <li><button onClick={() => router.push('/mis-recetas')} className="block w-full text-left px-4 py-2 hover:bg-gray-100">🧾 Mis Recetas</button></li>
            <li><button onClick={() => router.push('/favoritos')} className="block w-full text-left px-4 py-2 hover:bg-gray-100">⭐ Favoritos</button></li>
            <li><button onClick={() => router.push('/colecciones')} className="block w-full text-left px-4 py-2 hover:bg-gray-100">📚 Colecciones</button></li>
            <li><button onClick={() => router.push('/subir-receta')} className="block w-full text-left px-4 py-2 hover:bg-gray-100">⬆️ Subir receta</button></li>
            <li><button onClick={() => router.push('/planear-menu')} className="block w-full text-left px-4 py-2 hover:bg-gray-100">📅 Planear menú</button></li>
          </ul>
        </div>
      </header>

      <div className="p-4 max-w-4xl mx-auto">
        <input
          type="text"
          placeholder="Buscar recetas..."
          className="w-full border border-gray-300 p-2 rounded-md mb-8"
        />

        <div className="text-center mt-16">
          <h2 className="text-3xl font-bold mb-4">Explora el sabor de México</h2>
          <button
            className="bg-[#c1272d] hover:bg-[#a31e24] text-white px-6 py-3 rounded-full font-semibold"
            onClick={() => router.push('/categorias')}
          >
            Ver categorías
          </button>
        </div>
      </div>
    </main>
  )
}
