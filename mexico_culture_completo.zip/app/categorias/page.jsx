
'use client'
import { useRouter } from 'next/navigation'

export default function CategoriasPage() {
  const router = useRouter()

  return (
    <div className="min-h-screen bg-white text-gray-800 p-8">
      <h1 className="text-3xl font-bold text-center mb-8">Selecciona una categoría</h1>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
        <div onClick={() => router.push('/platillos')} className="bg-red-100 p-6 rounded-xl text-center cursor-pointer hover:bg-red-200">
          🍽 Platillos
        </div>
        <div onClick={() => router.push('/bebidas')} className="bg-green-100 p-6 rounded-xl text-center cursor-pointer hover:bg-green-200">
          🧃 Bebidas
        </div>
        <div onClick={() => router.push('/postres')} className="bg-yellow-100 p-6 rounded-xl text-center cursor-pointer hover:bg-yellow-200">
          🍰 Postres
        </div>
      </div>
    </div>
  )
}
