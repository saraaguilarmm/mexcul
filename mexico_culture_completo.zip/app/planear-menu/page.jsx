
'use client'
import { useRouter } from 'next/navigation'

export default function Page() {
  const router = useRouter()
  return (
    <div className="min-h-screen bg-white p-8 text-gray-800">
      <button onClick={() => router.back()} className="mb-4 text-blue-600 underline">🔙 Regresar</button>
      <h1 className="text-2xl font-bold mb-4">Pantalla: PLANEAR MENU</h1>
      <p>Contenido de la sección <strong>app/planear-menu/page.jsx</strong></p>
    </div>
  )
}
