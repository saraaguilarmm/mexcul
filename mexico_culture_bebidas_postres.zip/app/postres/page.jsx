'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import PlatilloCard from '../../components/PlatilloCard'

export default function PostresPage() {
  const router = useRouter()
  const [postres, setPostres] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchPostres = async () => {
      try {
        const response = await fetch('/api/postres')
        const data = await response.json()
        setPostres(data)
      } catch (error) {
        console.error('Error fetching postres:', error)
      } finally {
        setLoading(false)
      }
    }
    fetchPostres()
  }, [])

  return (
    <div className="min-h-screen bg-amber-50 text-green-800 p-8">
      <h1 className="text-3xl font-bold text-center mb-6">Postres Mexicanas</h1>
      <button onClick={() => router.back()} className="mb-4 text-sm underline">← Regresar</button>

      {loading ? (
        <div className="text-center">Cargando postres...</div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {postres.length === 0 ? (
            <p className="text-center">No hay postres disponibles.</p>
          ) : (
            postres.map((bebida) => (
              <PlatilloCard key={bebida.id} platillo={bebida} onClick={() => router.push(`/postres/${bebida.id}`)} />
            ))
          )}
        </div>
      )}
    </div>
  )
}