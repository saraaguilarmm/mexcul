'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import PlatilloCard from '../../components/PlatilloCard'

export default function BebidasPage() {
  const router = useRouter()
  const [bebidas, setBebidas] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchBebidas = async () => {
      try {
        const response = await fetch('/api/bebidas')
        const data = await response.json()
        setBebidas(data)
      } catch (error) {
        console.error('Error fetching bebidas:', error)
      } finally {
        setLoading(false)
      }
    }
    fetchBebidas()
  }, [])

  return (
    <div className="min-h-screen bg-amber-50 text-green-800 p-8">
      <h1 className="text-3xl font-bold text-center mb-6">Bebidas Mexicanas</h1>
      <button onClick={() => router.back()} className="mb-4 text-sm underline">← Regresar</button>

      {loading ? (
        <div className="text-center">Cargando bebidas...</div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {bebidas.length === 0 ? (
            <p className="text-center">No hay bebidas disponibles.</p>
          ) : (
            bebidas.map((bebida) => (
              <PlatilloCard key={bebida.id} platillo={bebida} onClick={() => router.push(`/bebidas/${bebida.id}`)} />
            ))
          )}
        </div>
      )}
    </div>
  )
}